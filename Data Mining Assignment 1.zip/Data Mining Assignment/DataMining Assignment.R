library(readr)
celebrity_deaths <- read_csv("C:/Users/Asus/Desktop/Data Mining Assignment/celebrity_deaths.csv")


df <- read.csv( file = "C:/Users/Asus/Desktop/Data Mining Assignment/celebrity_deaths.csv" , header = FALSE , col.names = c("age","birth_year","cause_of_death","death_month","death_year","famous_for","name","nationality") )
duplicated(df) #repeated row
unique(df[duplicated(df),]) #row diff,values same
unique(df)
View(unique(df)) #show duplicated data removed table

x_nonnegative <- x >= 0
#TO CHECK WHICH ELEMENT OF X OBEY THE 'NON NEGATIVE' EDIT RULES
df <- read_csv("C:/Users/Asus/Desktop/Data Mining Assignment/celebrity_deaths.csv")
library(editrules) 
(E <- editset(c("age >=0", "age <= 130")))
violatedEdits(E, df)
View(violatedEdits(E, df)) #no -tive value for age and no value exceed 130


View(na.omit(celebrity_deaths)) #View data without NA value
View(celebrity_deaths[complete.cases(celebrity_deaths),]) #View data without NA value (another way, but same result)